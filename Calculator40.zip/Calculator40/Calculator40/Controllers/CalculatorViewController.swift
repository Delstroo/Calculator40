//
//  CalculatorViewController.swift
//  Calculator40
//
//  Created by Delstun McCray on 8/16/21.
//

import UIKit

class CalculatorViewController: UIViewController {
    
    var previousNumber: Double = 0;
    var preformingMath = false
    var numberInCalculator:Double = 0;
    var operation = 0;
    var decimalWasUsed: Bool = false
    
    @IBOutlet weak var answerLabel: UILabel!
        
    @IBOutlet var buttons: [UIButton]!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        (buttons as NSArray).setValue(34, forKey: "cornerRadius")
    }

    
    
    //MARK: - Actions
    
    @IBAction func numberButton(_ sender: UIButton) {
        if preformingMath == true {
            answerLabel.text = String(sender.tag-1)
            numberInCalculator = Double(answerLabel.text!)!
            preformingMath = false
        } else {
            
            answerLabel.text = answerLabel.text! + String(sender.tag-1)
            numberInCalculator = Double(answerLabel.text!)!
            
        }
        
 
    }

    @IBAction func pemdasButtonTapped(_ sender: UIButton) {
            
            if answerLabel.text != "" && sender.tag != 11 && sender.tag != 16 {
                
                previousNumber = Double(answerLabel.text!)!
                
                if sender.tag == 12 {
                    answerLabel.text = "+";
                }//end of 12(+)
              
                else if sender.tag == 13 {
                    answerLabel.text = "÷";
                }//end of 13(/)
                
                else if sender.tag == 14 {
                    answerLabel.text = "x";
                }//end of 14(X)
                
                else if sender.tag == 15 {
                    answerLabel.text = "-";
                    
                }//end of 15(-)
                preformingMath = true;
                operation = sender.tag
            }
            else if sender.tag == 16 {
                if operation == 12 {
                    answerLabel.text = String(previousNumber + numberInCalculator)
                }
                
                else if operation == 13 {
                    answerLabel.text = String(previousNumber / numberInCalculator)
                }
                
                else if operation == 14 {
                    answerLabel.text = String(previousNumber * numberInCalculator)
                }
                
               else if operation == 15 {
                answerLabel.text = String(previousNumber - numberInCalculator)
                }
            }
            else if sender.tag == 11 {
                answerLabel.text = ""
                previousNumber = 0;
                numberInCalculator = 0;
                operation = 0;
        }
    }
    
}//end of func
